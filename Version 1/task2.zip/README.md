# Banking API

A small Java 8 / Spring Boot project for the banking assessment. The API uses a controller, service, Spring Data repositories, and JPA entities.

## Requirements

- JDK 8
- Maven
- MySQL 8+ for `task1.sql` (the default local setup uses H2)

Spring Boot 2.7 is used because it supports Java 8. It is an older release line; use it here only when Java 8 is a requirement.

## Run locally

```bash
mvn test
mvn spring-boot:run
```

The default setup uses an in-memory H2 database. It is recreated each time the app starts. The H2 console is available at `http://localhost:8080/h2-console`, using JDBC URL `jdbc:h2:mem:localcoin`, user `sa`, and a blank password.

## Use MySQL

1. Create a MySQL user and database for development.
2. Run `task1.sql`.
3. Configure the connection:

```bash
export SPRING_PROFILES_ACTIVE=mysql
export DB_URL='jdbc:mysql://localhost:3306/localcoin_banking?useSSL=false&serverTimezone=UTC'
export DB_USERNAME='your_user'
export DB_PASSWORD='your_password'
mvn spring-boot:run
```

The MySQL profile validates the schema; it does not update it. Seed an active branch before opening an account:

```sql
INSERT INTO branch (branch_code, name, address_line1, city, postal_code, country_code, status)
VALUES ('TOR-001', 'Toronto Central', '100 King Street', 'Toronto', 'M5H1J9', 'CA', 'ACTIVE');
```

## Endpoints

### Open an account

`POST /api/v1/accounts`

```json
{
  "firstName": "Asha",
  "middleName": null,
  "lastName": "Rao",
  "dateOfBirth": "1990-01-10",
  "email": "asha@example.com",
  "phone": "+14165550123",
  "addressLine1": "100 King Street",
  "addressLine2": null,
  "city": "Toronto",
  "provinceState": "Ontario",
  "postalCode": "M5H1J9",
  "countryCode": "CA",
  "branchId": 1,
  "currency": "CAD"
}
```

Returns `201 Created`. The branch must exist and be active.

### Get account details

`GET /api/v1/accounts/{accountId}`

Returns account, holder and balance details. A missing account returns `404`.

### Withdraw

`POST /api/v1/accounts/{accountId}/withdrawals`

```json
{
  "amount": 25.00,
  "currency": "CAD",
  "description": "ATM withdrawal",
  "idempotencyKey": "unique-request-123"
}
```

Use a unique idempotency key for each withdrawal on an account. Repeating the same request with the same account and key returns the original transaction; using that key with different details returns `409 Conflict`.

## Main design choices

- Amounts use `DECIMAL(19,2)` in MySQL and `BigDecimal` in Java. The service rejects amounts that require rounding.
- The service runs each withdrawal in one database transaction.
- The balance row is locked before funds are checked and changed.
- Each withdrawal records a transaction, a ledger entry and an audit event.
- The account number generator is a demo implementation, not a bank-approved allocation scheme.
- Authentication, account ownership checks, KYC workflow, key management for sensitive identity data, monitoring and operational controls are not included. This project is for assessment use, not live customer funds.

## Before submission

Run `mvn clean test` and review the results yourself. Also test the SQL against MySQL 8+; H2 tests do not prove MySQL compatibility.
