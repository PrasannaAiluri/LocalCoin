package ca.localcoin.banking.service;

import ca.localcoin.banking.api.ApiDtos.AccountResponse;
import ca.localcoin.banking.api.ApiDtos.MoneyRequest;
import ca.localcoin.banking.api.ApiDtos.MoneyResponse;
import ca.localcoin.banking.api.ApiDtos.OpenAccountRequest;
import ca.localcoin.banking.api.ApiDtos.OpenAccountResponse;
import ca.localcoin.banking.domain.Account;
import ca.localcoin.banking.domain.AccountBalance;
import ca.localcoin.banking.domain.AuditEvent;
import ca.localcoin.banking.domain.BankingTransaction;
import ca.localcoin.banking.domain.Branch;
import ca.localcoin.banking.domain.LedgerEntry;
import ca.localcoin.banking.domain.LegalPerson;
import ca.localcoin.banking.domain.LegalPersonAddress;
import ca.localcoin.banking.repository.AccountBalanceRepository;
import ca.localcoin.banking.repository.AccountRepository;
import ca.localcoin.banking.repository.AuditEventRepository;
import ca.localcoin.banking.repository.BankingTransactionRepository;
import ca.localcoin.banking.repository.BranchRepository;
import ca.localcoin.banking.repository.LedgerEntryRepository;
import ca.localcoin.banking.repository.LegalPersonAddressRepository;
import ca.localcoin.banking.repository.LegalPersonRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

@Service
public class BankingService {
    private final BranchRepository branches;
    private final LegalPersonRepository people;
    private final LegalPersonAddressRepository addresses;
    private final AccountRepository accounts;
    private final AccountBalanceRepository balances;
    private final BankingTransactionRepository transactions;
    private final LedgerEntryRepository ledgerEntries;
    private final AuditEventRepository auditEvents;
    private final CurrencyPolicy currencyPolicy;
    private final SecureRandom random = new SecureRandom();

    public BankingService(BranchRepository branches, LegalPersonRepository people,
                          LegalPersonAddressRepository addresses, AccountRepository accounts,
                          AccountBalanceRepository balances, BankingTransactionRepository transactions,
                          LedgerEntryRepository ledgerEntries, AuditEventRepository auditEvents,
                          CurrencyPolicy currencyPolicy) {
        this.branches = branches;
        this.people = people;
        this.addresses = addresses;
        this.accounts = accounts;
        this.balances = balances;
        this.transactions = transactions;
        this.ledgerEntries = ledgerEntries;
        this.auditEvents = auditEvents;
        this.currencyPolicy = currencyPolicy;
    }

    @Transactional
    public OpenAccountResponse openAccount(OpenAccountRequest request) {
        String currency = currencyPolicy.requireSupported(request.currency);
        Branch branch = branches.findById(request.branchId)
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
        if (branch.getStatus() != Branch.BranchStatus.ACTIVE) {
            throw new BusinessRuleException("Cannot open an account at an inactive branch");
        }

        // Keep account opening in one transaction so partial customer records are not left behind.
        LegalPerson person = new LegalPerson(request.firstName.trim(), blankToNull(request.middleName),
                request.lastName.trim(), request.dateOfBirth, blankToNull(request.email), blankToNull(request.phone));
        person = people.save(person);

        String countryCode = request.countryCode.trim().toUpperCase(Locale.ROOT);
        LegalPersonAddress address = new LegalPersonAddress(person, request.addressLine1.trim(),
                blankToNull(request.addressLine2), request.city.trim(), blankToNull(request.provinceState),
                request.postalCode.trim(), countryCode);
        addresses.save(address);

        Account account = accounts.save(new Account(generateAccountNumber(), person, branch, currency));
        balances.save(new AccountBalance(account));
        auditEvents.save(new AuditEvent("ACCOUNT_OPENED", "ACCOUNT", account.getId().toString(),
                AuditEvent.Outcome.SUCCESS, UUID.randomUUID().toString(),
                "currency=" + currency + ";branchId=" + branch.getId()));

        return new OpenAccountResponse(account.getId(), account.getAccountNumber(), account.getStatus().name());
    }

    @Transactional(readOnly = true)
    public AccountResponse getAccount(Long accountId) {
        Account account = accounts.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        AccountBalance balance = balances.findById(accountId)
                .orElseThrow(() -> new IllegalStateException("Balance row missing for account"));
        LegalPerson person = account.getHolder();

        StringBuilder name = new StringBuilder(person.getFirstName());
        if (person.getMiddleName() != null && !person.getMiddleName().trim().isEmpty()) {
            name.append(' ').append(person.getMiddleName().trim());
        }
        name.append(' ').append(person.getLastName());

        return new AccountResponse(account.getId(), account.getAccountNumber(), account.getStatus().name(),
                account.getCurrency(), account.getBranch().getId(), name.toString(), person.getDateOfBirth(),
                person.getEmail(), balance.getAvailableBalance(), balance.getLedgerBalance());
    }

    @Transactional
    public MoneyResponse withdraw(Long accountId, MoneyRequest request) {
        return postMoney(accountId, request, true);
    }

    // This extra endpoint makes it possible to test the withdrawal flow without manually editing balances.
    @Transactional
    public MoneyResponse deposit(Long accountId, MoneyRequest request) {
        return postMoney(accountId, request, false);
    }

    private MoneyResponse postMoney(Long accountId, MoneyRequest request, boolean withdrawal) {
        String currency = currencyPolicy.requireSupported(request.currency);
        BigDecimal amount;
        try {
            // Never silently round money. A value such as 10.005 must be rejected, not changed.
            amount = request.amount.setScale(2, RoundingMode.UNNECESSARY);
        } catch (ArithmeticException ex) {
            throw new BusinessRuleException("Amount must have no more than two decimal places");
        }
        if (amount.signum() <= 0) {
            throw new BusinessRuleException("Amount must be greater than zero");
        }

        String key = request.idempotencyKey.trim();
        String requestHash = hashRequest(accountId, withdrawal, amount, currency, request.description);

        // A retry after a timeout should return the first result instead of moving money twice.
        Optional<BankingTransaction> existing = transactions.findByIdempotencyKey(key);
        if (existing.isPresent()) {
            BankingTransaction previous = existing.get();
            if (!previous.getRequestHash().equals(requestHash)) {
                throw new ConflictException("This idempotency key was already used for another request");
            }
            return new MoneyResponse(previous.getId(), previous.getReference(), previous.getStatus().name(),
                    previous.getAmount(), previous.getCurrency(), true);
        }

        Account account = accounts.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        if (account.getStatus() != Account.AccountStatus.ACTIVE) {
            throw new BusinessRuleException("Account is not active");
        }
        if (!account.getCurrency().equals(currency)) {
            throw new BusinessRuleException("Request currency does not match account currency");
        }

        // Lock the row before checking funds. Concurrent withdrawals for this account wait here.
        AccountBalance balance = balances.findLockedByAccountId(accountId)
                .orElseThrow(() -> new IllegalStateException("Balance row missing for account"));

        // Two copies of the same request can arrive together. Recheck after the balance lock
        // so the second request can reuse the first transaction instead of debiting again.
        Optional<BankingTransaction> justPosted = transactions.findLockedByIdempotencyKey(key);
        if (justPosted.isPresent()) {
            BankingTransaction previous = justPosted.get();
            if (!previous.getRequestHash().equals(requestHash)) {
                throw new ConflictException("This idempotency key was already used for another request");
            }
            return new MoneyResponse(previous.getId(), previous.getReference(), previous.getStatus().name(),
                    previous.getAmount(), previous.getCurrency(), true);
        }

        if (withdrawal) {
            if (balance.getAvailableBalance().compareTo(amount) < 0) {
                throw new BusinessRuleException("Insufficient funds");
            }
            balance.debit(amount);
        } else {
            balance.credit(amount);
        }

        BankingTransaction transaction = new BankingTransaction(
                withdrawal ? BankingTransaction.TransactionType.WITHDRAWAL : BankingTransaction.TransactionType.DEPOSIT,
                withdrawal ? account : null, withdrawal ? null : account, amount, currency,
                blankToNull(request.description), key, requestHash);
        transaction = transactions.save(transaction);

        LedgerEntry.EntryType entryType = withdrawal ? LedgerEntry.EntryType.DEBIT : LedgerEntry.EntryType.CREDIT;
        ledgerEntries.save(new LedgerEntry(transaction, account, entryType, amount, currency,
                balance.getLedgerBalance()));

        auditEvents.save(new AuditEvent(withdrawal ? "WITHDRAWAL_POSTED" : "DEPOSIT_POSTED", "ACCOUNT",
                accountId.toString(), AuditEvent.Outcome.SUCCESS, key,
                "amount=" + amount.toPlainString() + ";currency=" + currency + ";transactionId=" + transaction.getId()));

        return new MoneyResponse(transaction.getId(), transaction.getReference(), transaction.getStatus().name(),
                amount, currency, false);
    }

    private String generateAccountNumber() {
        // This is only a demo allocation rule, not a banking-standard account-number algorithm.
        for (int attempt = 0; attempt < 10; attempt++) {
            StringBuilder number = new StringBuilder("LC");
            for (int digit = 0; digit < 18; digit++) {
                number.append(random.nextInt(10));
            }
            if (!accounts.existsByAccountNumber(number.toString())) {
                return number.toString();
            }
        }
        throw new DataIntegrityViolationException("Unable to allocate an account number");
    }

    private String hashRequest(Long accountId, boolean withdrawal, BigDecimal amount,
                               String currency, String description) {
        String normalizedDescription = blankToNull(description);
        String value = accountId + "|" + (withdrawal ? "WITHDRAWAL" : "DEPOSIT") + "|"
                + amount.toPlainString() + "|" + currency + "|"
                + (normalizedDescription == null ? "" : normalizedDescription);
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : bytes) {
                result.append(String.format("%02x", b & 0xff));
            }
            return result.toString();
        } catch (Exception ex) {
            throw new IllegalStateException("SHA-256 is not available", ex);
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}
