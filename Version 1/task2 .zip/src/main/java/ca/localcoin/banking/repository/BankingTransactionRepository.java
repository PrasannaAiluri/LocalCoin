package ca.localcoin.banking.repository;

import ca.localcoin.banking.domain.BankingTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.LockModeType;
import java.util.Optional;

public interface BankingTransactionRepository extends JpaRepository<BankingTransaction, Long> {
    Optional<BankingTransaction> findByIdempotencyKey(String idempotencyKey);

    // A locking read sees a just-committed row even in databases using repeatable-read snapshots.
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select t from BankingTransaction t where t.idempotencyKey = :key")
    Optional<BankingTransaction> findLockedByIdempotencyKey(@Param("key") String key);
}
