# Local Coin Banking API (Java 8)

A small Spring Boot project for the banking take-home task. The aim is to keep the flow easy to follow: controller -> service -> repository -> database.

## Technology

- Java 8
- Spring Boot 2.7.18
- Spring MVC, Bean Validation and Spring Data JPA
- MySQL 8 for the SQL schema; H2 for local runs and automated tests
- Maven

**Support note:** Spring Boot 2.7.18 is the final open-source 2.7 release. It supports Java 8, but the Spring team announced the end of open-source support for Spring Boot 2.x. Use this version only where Java 8 compatibility is mandatory and plan a supported upgrade path.

## Run locally

Install JDK 8 and Maven 3.5 or later, then run:

```bash
mvn test
mvn spring-boot:run
```

The default configuration uses an in-memory H2 database. It is empty when the application starts; the integration tests create their own branch data. H2 console: `http://localhost:8080/h2-console` (JDBC URL `jdbc:h2:mem:localcoin`, user `sa`, blank password).

## Run against MySQL

1. Start a MySQL 8 instance and run `task1.sql` against it.
2. Set credentials as environment variables rather than committing real ones:

```bash
export SPRING_PROFILES_ACTIVE=mysql
export DB_URL='jdbc:mysql://localhost:3306/localcoin_banking?useSSL=false&serverTimezone=UTC'
export DB_USERNAME='your_user'
export DB_PASSWORD='your_password'
mvn spring-boot:run
```

With the `mysql` profile, Hibernate validates the tables instead of changing them. If schema validation fails, compare the database to `task1.sql` before trying to disable validation.

## Seed a branch for manual testing

Run this SQL after `task1.sql`:

```sql
INSERT INTO branch (branch_code, name, address_line1, city, postal_code, country_code, status)
VALUES ('TOR-001', 'Toronto Central', '100 King Street', 'Toronto', 'M5H1J9', 'CA', 'ACTIVE');
```

## Endpoints

### Open account

`POST /api/v1/accounts`

```json
{
  "firstName": "Asha",
  "middleName": null,
  "lastName": "Rao",
  "dateOfBirth": "1990-01-10",
  "email": "asha@example.com",
  "phone": "+14165550123",
  "addressLine1": "100 King Street",
  "addressLine2": null,
  "city": "Toronto",
  "provinceState": "Ontario",
  "postalCode": "M5H1J9",
  "countryCode": "CA",
  "branchId": 1,
  "currency": "CAD"
}
```

Returns `201 Created` with account ID and status. The branch ID must exist and be active.

### Get account details

`GET /api/v1/accounts/{accountId}`

Returns account details, holder identity and both balances. Unknown IDs return `404`.

### Deposit (added only to make the assessment demo testable)

`POST /api/v1/accounts/{accountId}/deposits`

### Withdraw

`POST /api/v1/accounts/{accountId}/withdrawals`

Both money endpoints accept the same body:

```json
{
  "amount": 25.00,
  "currency": "CAD",
  "description": "ATM withdrawal",
  "idempotencyKey": "unique-client-request-123"
}
```

Use a new idempotency key for each new action and reuse the same key only when retrying that exact request. The application stores a hash of the request and rejects reuse of a key for a different request. The supported currencies in this starter all use two decimal places; other currencies are intentionally rejected until their precision rules are implemented.

## Design notes

- Money uses `DECIMAL(19,2)` in SQL and `BigDecimal` in Java. Inputs are not silently rounded.
- A balance row is locked before funds are checked and changed, so competing withdrawals serialize for the same account.
- The balance change, transaction, ledger entry and success audit event are committed in one database transaction.
- The ledger is the activity history; the balance table is there for quick reads. A production service should reconcile the two regularly.
- The account number generator is only a demo rule. A real bank would use an approved allocation/validation process and handle collisions at the database boundary.
- Authentication, account ownership authorization, KYC approval, application-level encryption/key management, rate limiting, monitoring and a formal retention policy are not implemented here. Do not deploy this assessment project to handle real customer funds or identity information.

## What to test before submission

- `mvn test` on your own Java 8 + Maven setup
- Run `task1.sql` on MySQL and start with the `mysql` profile
- Add tests for malformed currency/amount, inactive branches, idempotency-key conflict, and simultaneous withdrawals
- Update this README with the results you actually observed
